<?php
class Trego_Ajaxfilter_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 