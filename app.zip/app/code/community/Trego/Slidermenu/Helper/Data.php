<?php

class Trego_Slidermenu_Helper_Data extends Mage_Core_Helper_Abstract
{
   
}
